// self.addEventListener('Install',event=>console.log('installing',event));
// self.addEventListener('Activating',event=>console.log('activating',event));
// self.addEventListener('Fetching',event=>console.log('Fetching',event));
self.addEventListener('install', (e) => {
    console.log('[Service Worker] Install');
  });
  self.addEventListener('activate', (e) => {
    console.log('[Service Worker] activate');
  });
  self.addEventListener('fetch', (e) => {
    console.log(`[Service Worker] Fetched resource`);
  });